"""Milestone 10 tests: explicit multi-probe evaluation batches over suites.

Engine tests (module-scoped real history: domain -> tokenizer -> model ->
training -> checkpoints) prove M10 is a thin orchestration layer over M4:

  * every suite probe executes as an ordinary exact M4 evaluation (or is
    reused when identical evidence exists) — no second identity, no
    duplicate evidence from repeated runs
  * canonical suite order is respected; per-probe results expose each
    evaluation independently; NO aggregation of any kind exists
  * deterministic failure semantics: model/state/suite preflight errors
    persist nothing; per-probe execution failures are recorded cleanly with
    deterministic text and a ``failed`` run status
  * one immutable manifest per run; deterministic result_hash over the
    semantic execution (bookkeeping labels excluded) so logically identical
    runs reproduce it
  * dashboard keeps rendering the underlying M4 evaluations normally
  * API coverage: POST /suite-runs + model-scoped list/get with the
    established 404/409/422 mapping and 405 for update/delete
"""
from __future__ import annotations

import json
import random
import time

import pytest
from pydantic import ValidationError

from app.engine import ModelForge
from app.schemas import (
    ComparisonState,
    EvalStateKind,
    EvaluationConfig,
    ModelCreateRequest,
    ProbeSuiteCreateRequest,
    SuiteRunRecord,
    SuiteRunRequest,
    SuiteProbe,
    TokenizerConfig,
    TrainingConfig,
    TransformerConfig,
)

HEADS = ("river mountain cloud forest desert ocean valley island meadow canyon "
         "table chair lamp desk shelf couch rug clock mirror vase").split()
TAIL = ("flows stands gleams rises falls drifts looms shines hides waits").split()


def _domain_bytes(n: int = 240) -> bytes:
    rng = random.Random(11)
    out = []
    for i in range(n):
        h1, h2 = rng.sample(HEADS, 2)
        out.append(f"{h1} is {rng.choice(TAIL)} near {h2} with number {i}")
    return ("\n\n".join(out) + "\n").encode("utf-8")


class Env:
    """One temp root: model with real training history + tokenized domain."""

    def __init__(self, root):
        self.forge = ModelForge(root=root)

    def prepare(self):
        f = self.forge
        up = f.upload_dataset([("a.txt", _domain_bytes())], name="m10-dom")
        self.ds = up["dataset_id"]
        tok = f.train_tokenizer(TokenizerConfig(name="m10-tok", vocab_size=600),
                                dataset_id=self.ds)
        self.tok = tok.id
        f.tokenize_dataset(self.ds, tok.id)
        cfg = TransformerConfig(name="m10-main", vocab_size=640,
                                context_length=64, hidden_size=64,
                                n_layers=2, n_heads=4, n_kv_heads=2,
                                intermediate_size=128, seed=1)
        self.model_id = f.create_model(ModelCreateRequest(config=cfg))[0].id
        tokens = f.datasets.tokenized_artifact(self.ds, 1, self.tok)[0] \
            .splits["train"].count
        sp_epoch = max(1, (tokens // 32) // 8)
        f.run_training(TrainingConfig(
            method="continued_pretraining", model_id=self.model_id,
            dataset_id=self.ds, tokenizer_id=self.tok, learning_rate=3e-3,
            batch_size=8, max_seq_len=32, epochs=5,
            eval_every_steps=max(1, sp_epoch // 2), keep_best=False, seed=1))
        ckpts = f.list_checkpoints(self.model_id)
        self.ck_a = ckpts[len(ckpts) // 2].checkpoint_id
        self.ck_b = ckpts[-1].checkpoint_id

    # ------------------------------------------------------------------ #
    # helpers
    # ------------------------------------------------------------------ #

    def fresh_model(self, name: str = "m10-extra", seed: int = 31) -> str:
        return self.forge.create_model(ModelCreateRequest(config=TransformerConfig(
            name=name, vocab_size=640, context_length=64, hidden_size=64,
            n_layers=2, n_heads=4, n_kv_heads=2, intermediate_size=128,
            seed=seed)))[0].id

    def probe(self, seed: int, dsid: str | None = None, split: str = "validation",
              seq: int = 32, tok: str | None = None) -> SuiteProbe:
        return SuiteProbe(dataset_id=dsid or self.ds, split=split,
                          tokenizer_id=tok or self.tok, batch_size=8,
                          max_seq_len=seq, seed=seed)

    def register_suite(self, suite_id: str, probes) -> None:
        self.forge.register_probe_suite(ProbeSuiteCreateRequest(
            suite_id=suite_id, probes=probes))

    def run(self, suite_id: str, state: ComparisonState,
            model_id: str | None = None) -> SuiteRunRecord:
        return self.forge.run_suite(SuiteRunRequest(
            model_id=model_id or self.model_id, suite_id=suite_id, state=state))

    def eval_count(self, model_id: str | None = None) -> int:
        return len(self.forge.list_evaluations(model_id or self.model_id))

    def run_files(self) -> set[str]:
        root = self.forge.storage.root / "suite-runs"
        if not root.exists():
            return set()
        return {f"suite-runs/{d.name}/manifest.json"
                for d in root.iterdir() if d.is_dir()}


def cstate(ckpt=None, current=False) -> ComparisonState:
    if current:
        return ComparisonState(state_kind=EvalStateKind.CURRENT)
    return ComparisonState(state_kind=EvalStateKind.CHECKPOINT,
                           checkpoint_id=ckpt)


@pytest.fixture(scope="module")
def env(tmp_path_factory):
    e = Env(tmp_path_factory.mktemp("m10-root"))
    e.prepare()
    return e


# =========================================================================== #
# Execution: one-probe / multi-probe / current & checkpoint states
# =========================================================================== #

def test_one_probe_suite_on_checkpoint_state(env):
    f = env.forge
    env.register_suite("m10-one", [env.probe(seed=10001)])
    rec = env.run("m10-one", cstate(env.ck_b))
    assert rec.status.value == "completed"
    assert rec.probe_count == 1 and rec.completed_count == 1
    assert rec.reused_count == 0 and rec.failed_count == 0
    assert rec.suite_id == "m10-one"
    assert rec.state == cstate(env.ck_b)
    res = rec.results[0]
    assert res.outcome == "created" and res.evaluation_id and res.error is None
    assert res.probe.dataset_version == 1        # version resolved at run time
    # the result IS an ordinary M4 evaluation with the exact expected identity
    ev = f.get_evaluation(env.model_id, res.evaluation_id)
    assert ev.state_kind.value == "checkpoint" and ev.checkpoint_id == env.ck_b
    assert ev.dataset_id == env.ds and ev.seed == 10001
    assert ev.state_hash == rec.state_hash
    assert ev.config.get("batch_size") == 8 and ev.config.get("max_seq_len") == 32
    assert ev.result_hash and ev.created_at


def test_multi_probe_suite_canonical_order_current_state(env):
    f = env.forge
    # register deliberately out of canonical order: seeds [10013, 10011, 10012]
    env.register_suite("m10-multi", [env.probe(seed=10013),
                                     env.probe(seed=10011),
                                     env.probe(seed=10012)])
    rec = env.run("m10-multi", cstate(current=True))
    assert rec.status.value == "completed"
    assert [r.probe.seed for r in rec.results] == [10011, 10012, 10013]
    assert [r.outcome for r in rec.results] == ["created"] * 3
    assert rec.completed_count == 3 and rec.reused_count == 0
    # each probe maps to an independent M4 evaluation of the CURRENT state
    evs = [f.get_evaluation(env.model_id, r.evaluation_id)
           for r in rec.results]
    assert all(e.state_kind.value == "current" and e.checkpoint_id is None
               for e in evs)
    assert len({e.eval_id for e in evs}) == 3
    # recorded state hash equals the live verified canonical hash
    live_hash = f.comparison.verified_state_hash(
        env.model_id, ComparisonState(state_kind=EvalStateKind.CURRENT))
    assert rec.state_hash == live_hash


def test_suite_run_on_second_model_is_model_scoped(env):
    f = env.forge
    mid2 = env.fresh_model("m10-scope")
    env.register_suite("m10-scope-s", [env.probe(seed=10021)])
    rec = env.run("m10-scope-s", cstate(current=True), model_id=mid2)
    assert rec.model_id == mid2 and rec.status.value == "completed"
    # the run and its evaluations belong to model 2, never to model 1
    assert all(e.model_id == mid2 for e in f.list_evaluations(mid2))
    assert env.eval_count(mid2) == 1
    with pytest.raises(FileNotFoundError):
        f.get_suite_run(env.model_id, rec.suite_run_id)   # wrong model -> 404


# =========================================================================== #
# Evidence reuse: exact M4 identity, no duplicate evaluations
# =========================================================================== #

def test_repeated_run_reuses_evidence_no_duplicates(env):
    f = env.forge
    env.register_suite("m10-reuse", [env.probe(seed=10031),
                                     env.probe(seed=10032)])
    runs0 = env.run_files()
    evals0 = env.eval_count()
    r1 = env.run("m10-reuse", cstate(env.ck_b))
    assert env.eval_count() == evals0 + 2
    r2 = env.run("m10-reuse", cstate(env.ck_b))
    # identical evidence reused: same evaluations, no duplicate manifests
    assert [r.outcome for r in r2.results] == ["reused", "reused"]
    assert [r.evaluation_id for r in r2.results] == \
        [r.evaluation_id for r in r1.results]
    assert env.eval_count() == evals0 + 2
    assert env.run_files() == runs0 | {f"suite-runs/{r1.suite_run_id}/manifest.json",
                                       f"suite-runs/{r2.suite_run_id}/manifest.json"}
    # storage grew by exactly the two immutable run manifests
    root = f.storage.root
    before = {p.relative_to(root).as_posix(): p.read_bytes()
              for p in root.rglob("*") if p.is_file()}
    r3 = env.run("m10-reuse", cstate(env.ck_b))
    after = {p.relative_to(root).as_posix(): p.read_bytes()
             for p in root.rglob("*") if p.is_file()}
    new = set(after) - set(before)
    assert new == {f"suite-runs/{r3.suite_run_id}/manifest.json"}
    for path in before:
        assert after[path] == before[path]                 # byte-identical
    assert [r.outcome for r in r3.results] == ["reused", "reused"]


def test_suite_probe_identity_is_exact_m4_identity(env):
    f = env.forge
    # direct M4 evaluation with identical fields
    direct = f.run_evaluation(EvaluationConfig(
        model_id=env.model_id, checkpoint_id=env.ck_b, dataset_id=env.ds,
        split="validation", tokenizer_id=env.tok, batch_size=8,
        max_seq_len=32, seed=10041))
    env.register_suite("m10-id", [env.probe(seed=10041)])
    rec = env.run("m10-id", cstate(env.ck_b))
    res = rec.results[0]
    # exact identity -> the suite run REUSED the direct evaluation
    assert res.outcome == "reused" and res.evaluation_id == direct.eval_id
    # a different probe (other seed) is a different M4 evaluation
    env.register_suite("m10-id2", [env.probe(seed=10042)])
    rec2 = env.run("m10-id2", cstate(env.ck_b))
    ev2 = f.get_evaluation(env.model_id, rec2.results[0].evaluation_id)
    assert rec2.results[0].outcome == "created"
    assert ev2.eval_id != direct.eval_id and ev2.result_hash != direct.result_hash
    # result_hash of the run is semantic: probe set differs -> differs
    assert rec2.result_hash != rec.result_hash


# =========================================================================== #
# Failure semantics
# =========================================================================== #

def test_unknown_suite_or_state_persists_nothing(env):
    f = env.forge
    runs_before = env.run_files()
    evals_before = env.eval_count()
    with pytest.raises(FileNotFoundError, match="probe suite"):
        env.run("m10-ghost-suite", cstate(env.ck_b))
    # corrupt suite manifest -> RuntimeError (409 class), nothing persisted
    env.register_suite("m10-corrupt-s", [env.probe(seed=10051)])
    (f.storage.root / "probe-suites" / "m10-corrupt-s" / "manifest.json") \
        .write_bytes(b"{broken")
    with pytest.raises(RuntimeError, match="corrupt"):
        env.run("m10-corrupt-s", cstate(env.ck_b))
    # invalid checkpoint state -> FileNotFoundError before any probe runs
    with pytest.raises(FileNotFoundError, match="not found"):
        env.run("m10-corrupt-s", cstate("ghost-ckpt"))   # suite also corrupt...
    env.register_suite("m10-ok-s", [env.probe(seed=10052)])
    with pytest.raises(FileNotFoundError, match="not found"):
        env.run("m10-ok-s", cstate("ghost-ckpt"))
    with pytest.raises(FileNotFoundError, match="model"):
        env.forge.run_suite(SuiteRunRequest(model_id="ghost-model",
                                            suite_id="m10-ok-s",
                                            state=cstate(env.ck_b)))
    assert env.run_files() == runs_before               # nothing persisted
    assert env.eval_count() == evals_before


def test_missing_dataset_probe_recorded_failure(env):
    evals_before = env.eval_count()
    env.register_suite("m10-missing-ds",
                       [env.probe(seed=10061, dsid="ghost-dataset")])
    rec = env.run("m10-missing-ds", cstate(env.ck_b))
    assert rec.status.value == "failed"
    assert rec.probe_count == 1 and rec.failed_count == 1
    assert rec.completed_count == 0
    res = rec.results[0]
    assert res.outcome == "failed" and res.evaluation_id is None
    assert "FileNotFoundError" in res.error and "ghost-dataset" in res.error
    assert env.eval_count() == evals_before             # nothing fabricated
    # deterministic failure text -> identical rerun reproduces the hash
    rec2 = env.run("m10-missing-ds", cstate(env.ck_b))
    assert rec2.status.value == "failed"
    assert rec2.result_hash == rec.result_hash
    assert rec2.results[0].error == rec.results[0].error


def test_partial_failure_keeps_valid_probes_and_records_failure(env):
    f = env.forge
    evals_before = env.eval_count()
    env.register_suite("m10-partial",
                       [env.probe(seed=10071),
                        env.probe(seed=10072, tok="ghost-tokenizer")])
    rec = env.run("m10-partial", cstate(env.ck_b))
    assert rec.status.value == "failed"
    assert rec.completed_count == 1 and rec.failed_count == 1
    by_seed = {r.probe.seed: r for r in rec.results}
    ok, bad = by_seed[10071], by_seed[10072]
    assert ok.outcome == "created" and ok.evaluation_id is not None
    assert bad.outcome == "failed" and bad.evaluation_id is None
    assert bad.error and "ghost-tokenizer" in bad.error
    assert env.eval_count() == evals_before + 1         # only the valid probe ran
    assert len(f.list_suite_runs(env.model_id)) >= 1    # failed run persisted
    # remaining probes still executed deterministically (order preserved)
    assert [r.probe.seed for r in rec.results] == [10071, 10072]


def test_corrupt_existing_evaluation_manifest_becomes_fresh_run(env):
    """Unreadable evidence is treated as unavailable: a fresh exact M4 run
    replaces it (recorded as created) — never a fabricated result."""
    f = env.forge
    evals_before = env.eval_count()
    md = f.storage.model_dir(env.model_id) / "evaluations"
    dirs_before = len([p for p in md.iterdir() if p.is_dir()])
    env.register_suite("m10-evl-corrupt", [env.probe(seed=10081)])
    r1 = env.run("m10-evl-corrupt", cstate(env.ck_b))
    evid = r1.results[0].evaluation_id
    mpath = md / f"eval-{evid}" / "manifest.json"
    mpath.write_bytes(b"{corrupt json")
    r2 = env.run("m10-evl-corrupt", cstate(env.ck_b))
    res = r2.results[0]
    assert res.outcome == "created" and res.evaluation_id != evid
    assert r2.status.value == "completed"
    # corrupt record is invisible to reuse; a fresh manifest was written
    assert env.eval_count() == evals_before + 1         # corrupt one hidden
    assert len([p for p in md.iterdir() if p.is_dir()]) == dirs_before + 2


# =========================================================================== #
# Persistence, listing, hashing
# =========================================================================== #

def test_persistence_one_manifest_and_deterministic_listing(env):
    f = env.forge
    env.register_suite("m10-persist", [env.probe(seed=10091)])
    before = [r.suite_run_id for r in f.list_suite_runs(env.model_id)]
    a = env.run("m10-persist", cstate(env.ck_a))
    time.sleep(0.01)
    b = env.run("m10-persist", cstate(env.ck_a))
    d = f.storage.root / "suite-runs" / a.suite_run_id
    assert [p.name for p in d.iterdir()] == ["manifest.json"]
    # manifest on disk round-trips to the returned record
    disk = SuiteRunRecord(**json.loads(
        (d / "manifest.json").read_text()))
    assert disk.model_dump() == a.model_dump()
    # deterministic list: oldest first, new runs appended in order
    ids = [r.suite_run_id for r in f.list_suite_runs(env.model_id)]
    assert ids == before + [a.suite_run_id, b.suite_run_id]
    assert f.list_suite_runs(env.model_id) == f.list_suite_runs(env.model_id)
    assert f.get_suite_run(env.model_id, a.suite_run_id).result_hash == \
        a.result_hash
    with pytest.raises(FileNotFoundError, match="not found"):
        f.get_suite_run(env.model_id, "ghost-run")
    with pytest.raises(FileNotFoundError):
        f.list_suite_runs("ghost-model")


def test_result_hash_semantics_and_bookkeeping_fields(env):
    f = env.forge
    env.register_suite("m10-hash", [env.probe(seed=10101)])
    st_ck, st_cur = cstate(env.ck_b), cstate(current=True)
    r_ck1 = env.run("m10-hash", st_ck)
    r_ck2 = env.run("m10-hash", st_ck)          # reuse path
    r_cur = env.run("m10-hash", st_cur)         # different state evidence
    assert r_ck1.result_hash == r_ck2.result_hash
    assert r_cur.result_hash != r_ck1.result_hash
    # ids/timestamps/durations do not influence the semantic hash
    mutant = r_ck1.model_copy(update={
        "suite_run_id": "different-id",
        "created_at": r_ck1.created_at.replace(year=1999),
        "duration_seconds": 1234.5})
    assert f.suite_runs.result_hash(mutant) == r_ck1.result_hash
    # counts are plain execution bookkeeping; arithmetic holds
    for r in (r_ck1, r_cur):
        assert r.completed_count + r.failed_count == r.probe_count
        assert r.reused_count <= r.completed_count
        assert set(r.model_dump(mode="json")) >= \
            {"probe_count", "completed_count", "reused_count", "failed_count"}
    # no aggregated metric exists anywhere in the record
    j = r_ck1.model_dump(mode="json")
    blob = json.dumps(j)
    assert not any(k in blob for k in
                   ("average", "avg_loss", "total_loss", "score", "ranking"))


def test_listing_skips_corrupt_run_manifests_and_foreign_runs(env):
    f = env.forge
    env.register_suite("m10-list", [env.probe(seed=10111)])
    r = env.run("m10-list", cstate(env.ck_a))
    # corrupt one run manifest -> list/get semantics
    mpath = f.storage.root / "suite-runs" / r.suite_run_id / "manifest.json"
    backup = mpath.read_bytes()
    mpath.write_bytes(b"{broken")
    with pytest.raises(Exception):
        f.get_suite_run(env.model_id, r.suite_run_id)   # corrupt -> parse error
    mpath.write_bytes(backup)                            # restore
    assert f.get_suite_run(env.model_id, r.suite_run_id).suite_run_id == \
        r.suite_run_id


# =========================================================================== #
# Request schema validation
# =========================================================================== #

def test_suite_run_request_validation(env):
    with pytest.raises(ValidationError):
        SuiteRunRequest(model_id=env.model_id, suite_id="x",
                        state=ComparisonState(state_kind=EvalStateKind.CURRENT),
                        **{"bogus": 1})                 # extra field forbidden
    with pytest.raises(ValidationError):
        SuiteRunRequest(model_id=env.model_id, suite_id="x",
                        state=ComparisonState(state_kind=EvalStateKind.CHECKPOINT))
    # checkpoint state without id is rejected at the state level
    with pytest.raises(ValidationError):
        ComparisonState(state_kind=EvalStateKind.CHECKPOINT, checkpoint_id=None)
    assert cstate(env.ck_b).checkpoint_id == env.ck_b


# =========================================================================== #
# HTTP API coverage
# =========================================================================== #

SUITE_RUNS = "/api/v1/suite-runs"
MODEL_SUITE_RUNS = "/api/v1/models/{mid}/suite-runs"
MODELS = "/api/v1/models"
TRAIN_RUN = "/api/v1/training/run"


def _http_env(api_client, tag: str, train: bool):
    up = api_client.post("/api/v1/datasets/upload",
                         files=[("files", (f"{tag}.txt",
                                           _domain_bytes(120),
                                           "text/plain"))],
                         data={"name": f"api10-{tag}-ds"})
    ds = up.json()["dataset_id"]
    tok = api_client.post("/api/v1/tokenizers/train",
                          data={"config": json.dumps(
                              {"name": f"api10-{tag}-tok",
                               "vocab_size": 600}),
                                "dataset_id": ds}).json()["tokenizer"]["id"]
    api_client.post(f"/api/v1/datasets/{ds}/tokenize",
                    json={"tokenizer_id": tok})
    cfg = {"name": f"api10-{tag}-model", "vocab_size": 640,
           "context_length": 64, "hidden_size": 64, "n_layers": 2,
           "n_heads": 4, "n_kv_heads": 2, "intermediate_size": 128}
    mid = api_client.post(MODELS, json={"config": cfg}).json()["model"]["id"]
    ck_last = None
    if train:
        run = api_client.post(TRAIN_RUN, json={
            "method": "continued_pretraining", "model_id": mid,
            "dataset_id": ds, "tokenizer_id": tok, "learning_rate": 3e-3,
            "batch_size": 8, "max_seq_len": 32, "epochs": 3,
            "eval_every_steps": 3, "keep_best": False, "seed": 1})
        assert run.status_code == 200, run.text
        ck_last = api_client.get(f"{MODELS}/{mid}/checkpoints") \
            .json()[-1]["checkpoint_id"]
    return {"mid": mid, "ds": ds, "tok": tok, "ck": ck_last}


def test_suite_runs_api_lifecycle_reuse(api_client):
    h = _http_env(api_client, "life", train=True)
    mid, ds, tok, ck = h["mid"], h["ds"], h["tok"], h["ck"]
    probes = [{"dataset_id": ds, "split": "validation", "tokenizer_id": tok,
               "batch_size": 8, "max_seq_len": 32, "seed": 5001},
              {"dataset_id": ds, "split": "validation", "tokenizer_id": tok,
               "batch_size": 8, "max_seq_len": 32, "seed": 5002}]
    api_client.post("/api/v1/probe-suites",
                    json={"suite_id": "api10-life-suite", "probes": probes})
    body = {"model_id": mid, "suite_id": "api10-life-suite",
            "state": {"state_kind": "checkpoint", "checkpoint_id": ck}}
    n_eval0 = len(api_client.get(f"{MODELS}/{mid}/evaluations").json())
    r = api_client.post(SUITE_RUNS, json=body)
    assert r.status_code == 200, r.text
    rec = r.json()
    assert rec["status"] == "completed" and rec["probe_count"] == 2
    assert rec["reused_count"] == 0 and rec["failed_count"] == 0
    assert len(rec["results"]) == 2 and len(rec["result_hash"]) == 64
    assert all(x["outcome"] == "created" for x in rec["results"])
    assert n_eval0 + 2 == len(api_client.get(
        f"{MODELS}/{mid}/evaluations").json())
    # second identical run reuses; no duplicate evaluations
    r2 = api_client.post(SUITE_RUNS, json=body)
    assert r2.status_code == 200
    rec2 = r2.json()
    assert [x["outcome"] for x in rec2["results"]] == ["reused", "reused"]
    assert rec2["result_hash"] == rec["result_hash"]
    assert [x["evaluation_id"] for x in rec2["results"]] == \
        [x["evaluation_id"] for x in rec["results"]]
    assert len(api_client.get(f"{MODELS}/{mid}/evaluations").json()) == n_eval0 + 2
    # list + detail
    listing = api_client.get(MODEL_SUITE_RUNS.format(mid=mid)).json()
    assert [x["suite_run_id"] for x in listing] == [rec["suite_run_id"],
                                                    rec2["suite_run_id"]]
    got = api_client.get(f"{MODEL_SUITE_RUNS.format(mid=mid)}/"
                         f"{rec['suite_run_id']}")
    assert got.status_code == 200 and got.json()["result_hash"] == \
        rec["result_hash"]
    # dashboard stays valid + deterministic (evals render normally)
    dash = api_client.get(f"{MODELS}/{mid}/dashboard").json()
    assert dash["diagnostics"] == []
    evals_in_dash = {r["eval_id"] for g in dash["evaluations"]
                     for r in g["records"]}
    assert len(evals_in_dash) == n_eval0 + 2
    assert dash["result_hash"] == api_client.get(
        f"{MODELS}/{mid}/dashboard").json()["result_hash"]


def test_suite_runs_api_errors_and_immutability(api_client):
    h = _http_env(api_client, "err", train=False)
    mid, ds, tok = h["mid"], h["ds"], h["tok"]
    probe = {"dataset_id": ds, "split": "validation", "tokenizer_id": tok,
             "batch_size": 8, "max_seq_len": 32, "seed": 5011}
    api_client.post("/api/v1/probe-suites",
                    json={"suite_id": "api10-err-suite", "probes": [probe]})
    body = {"model_id": mid, "suite_id": "api10-err-suite",
            "state": {"state_kind": "current"}}
    # valid run on the current state (fresh model weights exist)
    r = api_client.post(SUITE_RUNS, json=body)
    assert r.status_code == 200 and r.json()["status"] == "completed"
    run_id = r.json()["suite_run_id"]
    # unknown suite -> 404 (corrupt suite -> 409 is covered at engine level)
    bad_suite = dict(body, suite_id="api10-ghost-suite")
    assert api_client.post(SUITE_RUNS, json=bad_suite).status_code == 404
    # invalid checkpoint state -> 404, malformed request -> 422
    ghost_state = dict(body, state={"state_kind": "checkpoint",
                                    "checkpoint_id": "ghost-ck"})
    assert api_client.post(SUITE_RUNS, json=ghost_state).status_code == 404
    missing_ck = dict(body, state={"state_kind": "checkpoint"})
    assert api_client.post(SUITE_RUNS, json=missing_ck).status_code == 422
    unknown_model = dict(body, model_id="ghost-model")
    assert api_client.post(SUITE_RUNS, json=unknown_model).status_code == 404
    # list/detail: unknown model 404, unknown run 404, wrong model 404
    assert api_client.get(MODEL_SUITE_RUNS.format(mid="ghost-model")) \
        .status_code == 404
    assert api_client.get(f"{MODEL_SUITE_RUNS.format(mid=mid)}/ghost-run") \
        .status_code == 404
    # immutable artifacts: no update/delete/patch endpoints
    assert api_client.put(SUITE_RUNS).status_code == 405
    assert api_client.delete(SUITE_RUNS).status_code == 405
    assert api_client.patch(f"{MODEL_SUITE_RUNS.format(mid=mid)}/{run_id}") \
        .status_code == 405
    # repeated identical run stays deterministic
    r2 = api_client.post(SUITE_RUNS, json=body)
    assert r2.json()["result_hash"] == r.json()["result_hash"]
